


create procedure [dbo].[dt_insert_t_history]
@t_adresse_ID int,
@t_user_ID int,
@title varchar (100),
@text varchar (100)

AS
SET NOCOUNT ON

declare @vorname varchar(100),
@name varchar(100),
@rolle varchar(100)

BEGIN

if(@title = 'empty')
	BEGIN
		SELECT @rolle = txt_rolle_de from t_user_rolle INNER JOIN t_rolle on t_user_rolle.t_rolle_id = t_rolle.id WHERE t_user_rolle.t_user_id = @t_user_ID
		set @title = @rolle + 'Anmerkung'
	END

SELECT @vorname = vorname , @name = name from t_user WHERE ID = @t_user_ID

Insert into t_history (t_adresse_ID, anzeige_status, vorname, name, txt_titel, txt_history, date_erfassung, temp, t_user_ID) values (@t_adresse_ID, 1, @vorname, @name, @title, @text, getdate(), 0, @t_user_ID)

END


GO

