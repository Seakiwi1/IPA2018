CREATE TRIGGER t_user_ondelete
   ON  t_user
   AFTER delete
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	delete from gn_customcategoryrecipients 
	where recipient_id in (select r.id from t_newsletter_email r join deleted d on r.email = d.email)

	delete from t_newsletter_email where email in (select email from deleted)
END
GO

