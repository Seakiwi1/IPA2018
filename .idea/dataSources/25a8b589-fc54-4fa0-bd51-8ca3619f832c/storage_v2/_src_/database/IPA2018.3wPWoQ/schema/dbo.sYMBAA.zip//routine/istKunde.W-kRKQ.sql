/*
Übergabe der t_Adresse_id um zu schauen, ob der Kunde 
noch mit irgeneiner URL Kunde ist^^
*/
CREATE FUNCTION [dbo].[istKunde] (@t_adresse_id int) 

RETURNS int
AS
BEGIN

declare @t_url_id int
declare @gekuendigt datetime
declare @anzahl int
set @anzahl = 0

declare c_kw CURSOR FOR
select U.id from t_url U where t_adresse_id = @t_adresse_id
open c_kw
FETCH NEXT FROM c_kw INTO @t_url_id
WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT TOP 1 @gekuendigt = gekuendigt from t_vertrag_typ V 
	where 
	V.t_url_id = @t_url_id 
	order by V.id desc
	
	IF (@gekuendigt >= getDate()) OR (@gekuendigt IS NULL) 
	BEGIN
		set @anzahl = 1
	END

FETCH NEXT FROM c_kw INTO @t_url_id
END
close c_kw
DEALLOCATE c_kw
return @anzahl


END
GO

