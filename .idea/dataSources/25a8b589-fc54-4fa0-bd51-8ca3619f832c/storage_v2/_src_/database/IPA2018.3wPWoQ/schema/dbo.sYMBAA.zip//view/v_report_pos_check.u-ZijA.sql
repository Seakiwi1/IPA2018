CREATE VIEW dbo.v_report_pos_check
AS
SELECT     R.ranking, R.page, R.possition, E.name, C.abkurz, RS.reportID, RS.keywordsID
FROM         dbo.t_ranking AS R INNER JOIN
                      dbo.t_engine AS E ON R.engineID = E.ID INNER JOIN
                      dbo.t_country_code AS C ON E.countryId = C.ID INNER JOIN
                      dbo.t_report_spec AS RS ON RS.rankingID = R.ID
GO

