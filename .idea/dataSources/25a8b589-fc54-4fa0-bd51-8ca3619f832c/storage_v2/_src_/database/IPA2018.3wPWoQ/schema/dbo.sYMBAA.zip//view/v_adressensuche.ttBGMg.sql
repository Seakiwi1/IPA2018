CREATE VIEW dbo.v_adressensuche
AS
SELECT     A.ID AS aID, U.ID AS t_url_id, SB.ID AS SBid, B.ID AS Bid, RTRIM(LTRIM(A.txt_www)) AS Url1, RTRIM(LTRIM(U.txt_www)) AS Url2, 
                      A.int_adress_status_ID AS astatus, RTRIM(LTRIM(A.txt_firma)) AS Firma, P.plz AS PLZ, RTRIM(LTRIM(P.ort_27)) AS Ort, K.txt_kuerzel_de AS Kanton, 
                      A.int_land_ID AS int_land_id, P.t_kanton_ID, A.adresse_ungueltig, BS.t_user_ID AS BSt_user_ID, BS.freigabe AS BSfreigabe, 
                      DA.txt_www AS DAtxt_www
FROM         dbo.t_adresse AS A INNER JOIN
                      dbo.t_plz AS P ON A.int_plz_ID = P.ID INNER JOIN
                      dbo.t_kanton AS K ON A.int_kanton_ID = K.ID LEFT OUTER JOIN
                      dbo.t_url AS U ON A.ID = U.t_adresse_id LEFT OUTER JOIN
                      dbo.t_domainalias AS DA ON U.ID = DA.t_url_id INNER JOIN
                      dbo.t_adresse_sub_branche AS ASB ON A.ID = ASB.t_adresse_ID INNER JOIN
                      dbo.t_sub_branche AS SB ON ASB.t_sub_branche_ID = SB.ID INNER JOIN
                      dbo.t_branche AS B ON SB.t_branche_ID = B.ID INNER JOIN
                      dbo.t_besitzer AS BS ON A.ID = BS.t_adresse_ID
GO

