create view v_seocheckeroverview
as

select r.ID,
	   r.UrlId,
	   r.CheckDate,
	   case when u.seo_check_deaktiviert = 1 then 8 else r.SeoTag end as SeoTag,
	   case when u.seo_freecounter_deaktiviert = 1 then 8 else r.freecounter end as Freecounter,
	   case when u.seo_piwik_deaktiviert = 1 then 8 else r.piwik end as Piwik,
	   case when u.seo_ftp_deaktiviert = 1 then 8 else r.ftp end as Ftp,
	   CustomerCareShow,
	   CustomerCareOk,
	   case when u.seo_string_deaktiviert = 1 then 8 else r.VirusCheck end as VirusCheck,
	   SafeBrowsing,
	   DelayDate,
	   case when u.seo_cms_deaktiviert = 1 then 8 else r.Cms end as Cms,
	   (select top 1 id from t_vertrag_typ v where v.t_url_id = r.urlid order by id desc) as LatestContractID,
	   (select top 1 id from t_seo s where s.t_url_id = r.urlid order by id desc) as LatestSeoID
from gscCheckReport r join t_url u on r.urlid = u.id

GO

