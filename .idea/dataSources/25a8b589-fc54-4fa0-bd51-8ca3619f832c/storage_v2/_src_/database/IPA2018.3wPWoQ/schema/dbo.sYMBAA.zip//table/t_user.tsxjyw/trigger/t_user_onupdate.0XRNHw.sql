CREATE TRIGGER t_user_onupdate
   ON  t_user
   AFTER update
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	update t_newsletter_email set abgemeldet = getdate()
	where email in (select u.email from inserted u join deleted d on u.email = d.email 
	where d.status = 1 and u.status = 0)
END
GO

