CREATE PROCEDURE gn_AddCustomCategory (
	@name nvarchar(100)
)	
AS
BEGIN
	insert into gn_CustomCategories(name) values(@name);
END
GO

