

CREATE PROCEDURE [dbo].[dt_gratislaufzeit]

	@vertrag_id 	int 		= 0,
	@user_id	int 		= 0,
	@bemerkung	nvarchar(150) 	= '',
	@monate		int 		= 0
AS

SET NOCOUNT ON

declare @name nvarchar(100)
declare @vorname nvarchar(100)
declare @adresse_id int
declare @rolle_id int
declare @datum_int nvarchar(50)

set @adresse_id = (SELECT TOP 1 A.ID FROM t_adresse A INNER JOIN t_url U ON A.id = U.t_adresse_id INNER JOIN t_vertrag_typ VT ON VT.t_url_id = U.id WHERE VT.id = @vertrag_id)
set @name = (SELECT name FROM t_user WHERE id = @user_id)
set @vorname = (SELECT vorname FROM t_user WHERE id = @user_id)
set @rolle_id = (SELECT TOP 1 t_rolle_id FROM t_user_rolle WHERE t_user_id = @user_id ORDER BY t_rolle_id DESC)

-- Das Datum im Rückwärtsformat für evtl. Sortierung -History
set @datum_int = 
	LTRIM(RTRIM(STR(YEAR(GETDATE())))) +
	LTRIM(RTRIM((CASE WHEN MONTH(GETDATE()) < 10 THEN '0' + LTRIM(RTRIM(STR(MONTH(GETDATE())))) ELSE STR(MONTH(GETDATE())) END))) +
	LTRIM(RTRIM((CASE WHEN DAY(GETDATE()) < 10 THEN '0' + LTRIM(RTRIM(STR(DAY(GETDATE())))) ELSE STR(DAY(GETDATE())) END)))

-- Gratislaufzeit eintragen
INSERT INTO t_gratislaufzeiten
	(t_vertrag_typ_id, t_rolle_id, t_user_id, txt_description, int_months, datum_vergabe)
	VALUES
	(@vertrag_id, @rolle_id, @user_id, @bemerkung, @monate, GETDATE())

-- History Eintrag generieren
INSERT INTO t_history
	(t_adresse_id, anzeige_status, name, vorname, txt_titel, txt_history, datum, date_erfassung, t_user_id)
	VALUES
	(@adresse_id, 1, @name, @vorname, 'Zusätzliche Gratislaufzeit ' + LTRIM(RTRIM(STR(@monate))) + ' Monate' , 'Grund: ' + @bemerkung, @datum_int, GETDATE(), @user_id)

-- Vertragsende ausrechnen, berücksichtige alle Zusatzmonate
declare @anfang datetime
declare @dauer int
declare @alle_gratis int
declare @gratis_vertrag int
declare @alle_monate int
declare @neu_ende datetime

set @anfang = (SELECT vertragsstart FROM t_vertrag_typ WHERE id = @vertrag_id)
set @dauer = (SELECT vertragsdauer FROM t_vertrag_typ WHERE id = @vertrag_id)
set @alle_gratis = (SELECT SUM(int_months) FROM t_gratislaufzeiten WHERE t_vertrag_typ_id = @vertrag_id)
set @gratis_vertrag = (SELECT gratis_monate FROM t_vertrag_typ WHERE id = @vertrag_id)
set @alle_monate = @gratis_vertrag + @alle_gratis
set @neu_ende = DATEADD(YEAR, @dauer, @anfang)
set @neu_ende = DATEADD(MONTH, @alle_monate, @neu_ende)

-- Vertragsende updaten
UPDATE t_vertrag_typ SET vertragsende = @neu_ende WHERE id = @vertrag_id


GO

