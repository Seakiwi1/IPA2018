



CREATE PROCEDURE [dbo].[dt_vertraege_verlaengerung]

AS

SET NOCOUNT ON

-- Datum einstellen
declare @OneWeek datetime
declare @OneYear datetime
declare @ToDay datetime

set @ToDay = GETDATE()
set @OneWeek = DATEADD(DAY, 7, @ToDay)
set @OneYear = DATEADD(YEAR, 1, @ToDay)


-- Hole Verträge die auslaufen und nicht gekündigt worden oder erst in einem Jahr gekündigt sind
declare @old_id int
declare @vertrag_id int
declare @url_id int
declare @temp_id int

declare @jahresv int
declare @vertragsv int
declare @start datetime
declare @ende datetime
declare @dauer int

declare @jahresv_new int
declare @vertragsv_new int
declare @start_new datetime
declare @ende_new datetime
declare @dauer_new int

declare @www nvarchar(100)
declare @firma nvarchar(100)
declare @plz nvarchar(100)
declare @ort nvarchar(100)

--Initialisiere Cursor für die Abfrage
DECLARE vertraege CURSOR FOR
	SELECT
		id, t_url_id, istVerlaengerung, Vertragsverlaengerung, 
		vertragsstart, vertragsende, vertragsdauer
	FROM
		t_vertrag_typ V 
	WHERE
		id > 0
		AND MONTH(vertragsende) = MONTH(DATEADD(MONTH, 1, @ToDay))
		AND YEAR(vertragsende) = YEAR(@ToDay)
		AND (gekuendigt IS NULL
			OR (gekuendigt >= @OneWeek AND gekuendigt <= @OneYear)
		)
	ORDER BY
		t_url_id ASC,
		vertragsstart DESC

--Verarbeite Cursor
OPEN vertraege
	FETCH NEXT FROM vertraege INTO @old_id, @url_id, @jahresv, @vertragsv, @start, @ende, @dauer
	WHILE @@FETCH_STATUS = 0
		BEGIN
			if(@dauer = 1)
				BEGIN set @vertragsv_new = (@vertragsv + 1) END
			else
				BEGIN set @vertragsv_new = 0 END

			if(@dauer > 1)
				BEGIN set @dauer_new = @dauer - 1
					set @jahresv_new = 1 END
			else
				BEGIN set @dauer_new = 1
					set @jahresv_new = 0 END

			set @start_new = DATEADD(DAY, 1, @ende)
			set @ende_new = DATEADD(YEAR, 1, @ende)

			--Mit diesem Insert neuen Vertrag einfügen
			/*INSERT INTO t_vertrag_typ
				(t_url_id, vertragsdauer, vertragsstart, vertragsende, istVerlaengerung, Vertragsverlaengerung)
				VALUES
				(@url_id, @dauer_new, @start_new, @ende_new, @jahresv_new, @vertragsv_new) 
			set @temp_id = SCOPE_IDENTITY() */
			set @temp_id = @old_id

			--Trage alles für weitere Verarbeitung in temporäre Tabelle ein.
			SELECT @www = U.txt_www, @firma = A.txt_firma, @plz = P.plz, @ort = P.ort_27
			FROM t_vertrag_typ V 
				LEFT JOIN t_url U ON U.id = V.t_url_id
				LEFT JOIN t_adresse A ON U.t_adresse_id = A.id
				LEFT JOIN t_plz P ON A.int_plz_id = P.id
			WHERE
				V.id = @temp_id


			INSERT INTO t_vertraege_verlaengerungen (
				t_vertrag_typ_id, firma, www, plz, ort, start, ende, jahresv, vertragsv, dauer, eintragung
			)VALUES(
				@temp_id, @firma, @www, @plz, @ort, @start_new, @ende_new, @jahresv_new, @vertragsv_new, @dauer_new, GETDATE()
			)

			FETCH NEXT FROM vertraege INTO @old_id, @url_id, @jahresv, @vertragsv, @start, @ende, @dauer
		END
CLOSE vertraege
DEALLOCATE vertraege

SELECT * FROM t_vertraege_verlaengerungen WHERE MONTH(eintragung) = MONTH(GETDATE()) And YEAR(eintragung) = YEAR(GETDATE())


GO

