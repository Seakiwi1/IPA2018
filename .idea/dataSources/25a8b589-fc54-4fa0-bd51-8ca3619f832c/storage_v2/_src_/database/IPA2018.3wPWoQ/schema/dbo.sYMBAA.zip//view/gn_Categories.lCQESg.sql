
CREATE view [dbo].[gn_Categories]
as
select 1 as id, 'Kunden' as name, null as category_id, 
	(select count(*) from gn_CategoryRecipients where category_id = 1) as numberofrecipients
union
select 2,  'Kunden mit abgelaufenem Vertrag', 1,
	(select count(*) from gn_CategoryRecipients where category_id = 2)
union
select 3, 'Kunden mit aktuelem Vertrag', 1,
	(select count(*) from gn_CategoryRecipients where category_id = 3)
union
select 4, 'Technischer Kontakten', null, 
	(select count(*) from gn_CategoryRecipients where category_id = 4)
union
select 5, 'Nicht Markiert als Kunde', null,
	(select count(*) from gn_CategoryRecipients where category_id = 5)
union
select 6, 'Nicht erfasste', null,
	(select count(*) from gn_CategoryRecipients where category_id = 6)
union
select id, name, category_id,
	(select count(*) from gn_CategoryRecipients where category_id = c.id)
from gn_CustomCategories c
GO

