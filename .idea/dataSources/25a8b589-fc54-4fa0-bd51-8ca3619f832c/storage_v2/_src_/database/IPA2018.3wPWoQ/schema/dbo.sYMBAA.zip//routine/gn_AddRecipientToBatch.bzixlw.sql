create procedure gn_AddRecipientToBatch
(
	@batchid uniqueidentifier,
	@email nvarchar(100),
	@vorname nvarchar(50),
	@nachname nvarchar(50),
	@anrede nvarchar(20)
)
as

declare @anredeID int;

select @anredeID = ID from t_anrede where txt_anrede_de = @anrede;

insert into gn_RecipientBatches
values (@batchid, @vorname, @nachname, @anredeID, @email)

GO

