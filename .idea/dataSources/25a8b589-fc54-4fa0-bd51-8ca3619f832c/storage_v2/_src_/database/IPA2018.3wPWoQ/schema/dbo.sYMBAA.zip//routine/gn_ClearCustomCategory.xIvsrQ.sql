CREATE PROCEDURE [dbo].[gn_ClearCustomCategory] (
	@id int
)	
AS
BEGIN
	create table #recipients (id int);

	insert into #recipients 
	select recipient_id from gn_CustomCategoryRecipients where Category_ID = @id;

	delete from gn_CustomCategoryRecipients where Category_ID = @id;

	delete e from t_newsletter_email e join #recipients r on e.id = r.id
	where e.abgemeldet is null
		and not exists(select 1 from gn_CategoryRecipients cr where cr.recipient_id = r.id)

	drop table #recipients
END
GO

