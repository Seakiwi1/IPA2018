-- =============================================
-- Author:		Gerd Thillmann
-- Create date: 25.05.2016
-- Description:	Anzahl der SEOs eines Mitarbeiters im gegebenen Monat
-- =============================================
CREATE FUNCTION [dbo].[getAnzahlSEOproMA] (@monat int, @jahr int, @t_user_id int)
RETURNS int
AS
BEGIN

declare @anzahl int

if (@monat >= 1)
BEGIN
select @anzahl = count(t_user_id) from t_seo S
where t_user_id = @t_user_id 
and month(optimierung_aufgeschaltet) = @monat
and year(optimierung_aufgeschaltet) = @jahr
END
ELSE
BEGIN
select @anzahl = count(t_user_id) from t_seo S
where t_user_id = @t_user_id 
and year(optimierung_aufgeschaltet) = @jahr
END

	-- Return the result of the function
	RETURN @anzahl

END
GO

