
CREATE FUNCTION [dbo].[anzBesitzerMitPendenz]
(
	@t_user_id int
)
RETURNS int
AS
BEGIN
DECLARE @anzahl int
SET @anzahl = 0 

SELECT @anzahl = COUNT(DISTINCT(A.id)) FROM t_besitzer B 
INNER JOIN t_adresse A ON A.id = B.t_adresse_id 
INNER JOIN t_pendenz P ON P.t_adresse_id = B.t_adresse_id 
WHERE 
(A.adresse_ungueltig = 0 OR A.adresse_ungueltig IS NULL OR A.adresse_ungueltig = '') 
AND A.int_adress_status_id < 9 AND P.erledigt <> 1 AND B.t_user_id = @t_user_id
group by A.id

RETURN @anzahl
END
GO

