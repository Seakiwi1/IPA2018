



CREATE procedure [dbo].[dt_getuserlist]

@UserID 	varchar(200)

AS
SET NOCOUNT ON

SELECT ('<option value=""' + LTRIM(RTRIM(STR(U.id))) + '""' + CASE U.id WHEN @UserID THEN ' selected' ELSE '' END + '>' + LTRIM(RTRIM(STR(U.vorname))) + ' ' + LTRIM(RTRIM(STR(U.name))) + '</option>') FROM t_user U WHERE U.status = 1 AND U.id = @UserID


GO

