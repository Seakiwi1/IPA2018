
CREATE FUNCTION [dbo].[get_t_user_name] (@t_user_id int)  
RETURNS varchar(100)  AS 
BEGIN 

DECLARE 
@name varchar(100),
@vorname varchar(100)

SELECT @name = name, @vorname = vorname from t_user where id = @t_user_id 

RETURN @vorname + ' ' + @name

END
GO

