
CREATE procedure [dbo].[dt_insert_t_vertrag_typ]

@t_url_id			int,
@vertragsstart		datetime,
@vertragsende		datetime,
@vertragsdauer		int,
@kundenblatversand	datetime,
@gratis_monate		int,
@gekuendigt			datetime,
@auftragsnummer		nvarchar(50),
@vertrag_bemerkung	nvarchar(2000),
@eingeschrieben		datetime,
@istVerlaengerung	int,
@anzahl_kw			int,
@standardpreis		money,
@spezialpreis		money,
@backlink			int

AS

SET NOCOUNT ON


BEGIN

		
	Insert into t_vertrag_typ (vertragsdauer,vertragsstart,vertragsende,gekuendigt,kundenblatversand,bemerkung,gratis_monate,auftragsnummer,t_url_id,eingeschrieben,istVerlaengerung,anzahl_kw,standardpreis,spezialpreis,backlink) values (@vertragsdauer,@vertragsstart,@vertragsende,@gekuendigt,@kundenblatversand,@vertrag_bemerkung,@gratis_monate,@auftragsnummer,@t_url_id,@eingeschrieben,@istVerlaengerung,@anzahl_kw,@standardpreis,@spezialpreis,CONVERT(BIT,@backlink))
	
	
	if exists(Select t_url_id from t_zahlungstatus where t_url_id = @t_url_id)
		BEGIN
				
			declare @not int
			set @not = 1
		END
	else 
		BEGIN
				Insert into  t_zahlungstatus(t_url_id) values (@t_url_id)
		END
END
GO

