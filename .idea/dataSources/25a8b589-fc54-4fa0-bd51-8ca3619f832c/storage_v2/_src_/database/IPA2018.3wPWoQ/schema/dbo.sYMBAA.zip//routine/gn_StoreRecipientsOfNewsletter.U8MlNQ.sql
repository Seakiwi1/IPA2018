create procedure gn_StoreRecipientsOfNewsletter
(
	@id int
)
as
	insert into gn_NewsletterRecipients
	select distinct recipient_id, @id
	from gn_NewsletterCategories cn join gn_CategoryRecipients ce on cn.category_id = ce.category_id
	where newsletter_id = @id
GO

