
	create view [dbo].[gn_RecipientsWithAPData]
	with schemabinding
	as
		select n.id recipient_id, a.id as address_id
		from dbo.t_newsletter_email n
			join dbo.t_adresse a on n.email = a.txt_ap_email
		where ((a.txt_ap_name is not null and a.txt_ap_name <> '')
				or (a.txt_ap_vorname is not null and a.txt_ap_vorname <> ''))
                and (adresse_ungueltig is null or adresse_ungueltig = 0)
  GO

