
CREATE FUNCTION [dbo].[getVorundNachnamePerID] (@t_user_id int)
RETURNS varchar(100)  AS 
BEGIN 

DECLARE @nachname varchar(100)
DECLARE @vorname varchar(100)
DECLARE @namekpl varchar(100)


SELECT @vorname =  t_user.vorname, @nachname = t_user.name from t_user where id = @t_user_id 
set @namekpl = SUBSTRING(@vorname, 1, 1) + '.' + @nachname
RETURN @namekpl

END
GO

