CREATE procedure [dbo].[dt_ranking]

@myRanking 	int,
@myPage		int,
@myPosition	int,
@engineID	int

AS
SET NOCOUNT ON

declare @temp_id int


	if exists (Select ID from t_ranking where (ranking = @myRanking AND page=@myPage AND possition=@myPosition AND engineID=@engineID ))
		BEGIN
		Select ID from t_ranking where (ranking = @myRanking AND page=@myPage AND possition=@myPosition AND engineID=@engineID )
		END
	else
		BEGIN
		 Insert into t_ranking (ranking,page,possition,engineID) values (@myRanking,@myPage,@myPosition,@engineID)
		 SELECT @temp_id = Scope_Identity()
   		 SELECT temp_id = @temp_id

		END
GO

