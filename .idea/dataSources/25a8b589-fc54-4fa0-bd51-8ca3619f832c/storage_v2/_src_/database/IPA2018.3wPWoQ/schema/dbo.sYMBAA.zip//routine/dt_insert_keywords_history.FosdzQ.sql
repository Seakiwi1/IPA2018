
CREATE procedure [dbo].[dt_insert_keywords_history]

@t_kw_vorschlag_id int,
@datum_versendet_old smalldatetime,
@date_erfassung  smalldatetime,
@txt_titel nvarchar(50),
@t_adresse_id int,
@vorname nvarchar(50),
@name nvarchar(50)


AS
SET NOCOUNT ON

Insert into t_history (t_adresse_id,vorname,name,anzeige_status,txt_titel,date_erfassung) values (@t_adresse_id,@vorname,@name,2,@txt_titel,@date_erfassung)


	if exists(Select t_kw_vorschlag_id from t_kw_vorschlag_history where t_kw_vorschlag_id = @t_kw_vorschlag_id)
		BEGIN
				Update t_kw_vorschlag_history SET datum_versendet_old= @datum_versendet_old where t_kw_vorschlag_id = @t_kw_vorschlag_id

		END
	else
		BEGIN
				Insert into t_kw_vorschlag_history (t_kw_vorschlag_id,datum_versendet_old) values (@t_kw_vorschlag_id,@datum_versendet_old)
		END

GO

