
CREATE view [dbo].[gn_CategoryRecipients]
AS
--1. Kunden
select distinct 1 as category_id, recipient_id 
from gn_Clients WITH (NOEXPAND)
union
--2. Kunden mit abgelaufenem Vertrag
select 2, recipient_id 
from gn_Clients WITH (NOEXPAND)
group by recipient_id
having max(contract_enddate) <= getdate()
union
--3. Kunden mit aktuelem Vertrag
select 3, recipient_id 
from gn_Clients WITH (NOEXPAND)
group by recipient_id
having max(contract_enddate) > getdate()
union
--4. Technischer Kontakten
select distinct 4, recipient_id
from gn_TechnicalAddresses WITH (NOEXPAND)
union
--5. Nicht Markiert als Kunde
select 5, a.recipient_id
from gn_NotTechnicalAddresses a WITH (NOEXPAND)
where not exists(select 1 from gn_Clients k WITH (NOEXPAND) where k.recipient_id = a.recipient_id)
	and not exists(select 1 from gn_TechnicalAddresses ta WITH (NOEXPAND) where a.recipient_id = ta.recipient_id)
union
--6. Nicht erfasste
select 6, n.id
from
	dbo.t_newsletter_email n
where not exists(select 1 from gn_NotTechnicalAddresses a WITH (NOEXPAND) where a.recipient_id = n.id)
and not exists(select 1 from gn_TechnicalAddresses tk WITH (NOEXPAND) where tk.recipient_id = n.id)
and not exists(select 1 from gn_CustomCategoryRecipients cc where cc.recipient_id = n.id)
and not exists(select 1 from gn_NotValidAddresses nv where nv.recipient_id = n.id)
and n.abgemeldet is null
union
--custom categories
select c.id, n.id
from gn_CustomCategories c
join gn_CustomCategoryRecipients cr on c.id = cr.category_id
join t_newsletter_email n on n.id = cr.recipient_id
where n.abgemeldet is null
GO

