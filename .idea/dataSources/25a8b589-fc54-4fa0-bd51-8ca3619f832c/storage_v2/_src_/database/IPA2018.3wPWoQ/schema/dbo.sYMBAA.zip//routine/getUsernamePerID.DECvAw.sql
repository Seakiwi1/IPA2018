/* 
Übergabeparameter : t_user.id 
Rückgabewert : (Nach)name des Users 
*/

CREATE FUNCTION [dbo].[getUsernamePerID] (@t_user_id int)  
RETURNS varchar(100)  AS 
BEGIN 

DECLARE @nachname varchar(100)

SELECT @nachname =  t_user.name from t_user where id = @t_user_id 

RETURN @nachname

END


GO

