CREATE view v_url_clean
as
select * from t_url where txt_www is not null and txt_www <> '' and txt_www not like '% CONTENT%' and txt_www not like '% ADWORDS%'
GO

