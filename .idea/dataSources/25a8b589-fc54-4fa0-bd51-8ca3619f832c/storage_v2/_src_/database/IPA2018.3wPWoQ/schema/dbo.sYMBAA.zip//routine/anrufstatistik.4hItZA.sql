/*
modus = 
1   - Anruf angenommen
2   - Anruf nicht angenommen
3   - Entscheidungsträger erreicht
4   - Entscheidungsträger nicht erreicht
5   - Mutiert am
6   - Neue Adresse erfasst am
7   - Adresse ungültig
8   - Nummer nicht mehr in Betrieb
9   - Privatnummer
10 - Firma nicht mehr vorhanden
11 - Bereits Kunde
12 - Doppelter Datensatz
13 - Schon optmiert
14 - Sonstiges
15 - Anz. Pendenzen gesetzt
16 - Anz. Newsletter erfasst (order by t_adresse_id)
17 - Termin gesetzt
18 - Termin für den Zeitraum X
19 - Anzahl Adressen die qualifiziert wurden
20 - Anzahl Anrufpendenz qual. Adressen
	 

TODO : 
16 - Abschlussquote Anzahl wahrgenommene Termine / Abschlüsse
17 - Quote Anzahl Anrufe / Entscheidungsträger erreicht 
18 - Quote Anzahl Entscheidungsträger erreicht / gesetzte Termine

von, bis Datum welcher Zeitraum
ma = t_user_id
*/

CREATE FUNCTION [dbo].[anrufstatistik] (@von datetime,@bis datetime,@modus int,@ma int)  
RETURNS int  AS 
BEGIN 

DECLARE @anzahl int
DECLARE @vorname varchar(100)
DECLARE @nname varchar(100)

set @anzahl = 0	
set @bis = dateadd(day, 1, @bis)	

/*SELECT @vorname = u.vorname , @nname = u.name from t_user u where u.id = @ma*/

if (@modus = 1) 
BEGIN
	SELECT @anzahl = COUNT(id) from t_anrufstatistik h
	where 
	h.modus = 1 AND
	h.t_user_id = @ma AND
	date_erfassung  between @von AND @bis 
	/*group by h.t_adresse_id*/
END

if (@modus = 2) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_anrufstatistik h
	where 
	h.modus = 2 AND
	h.t_user_id = @ma AND
	date_erfassung  between @von AND @bis 
	/*group by h.t_adresse_id*/
END

if (@modus = 3) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_anrufstatistik h
	where 
	/*h.entscheidungstraeger = 'Entscheidungsträger erreicht'   AND*/
	h.modus = 3 AND
	h.t_user_id = @ma AND
	date_erfassung  between @von AND @bis 
	/*group by h.t_adresse_id*/
END

if (@modus = 4) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_anrufstatistik h
	where 
	/*h.entscheidungstraeger = 'Entscheidungsträger nicht erreicht'   AND*/
	h.modus = 4 AND
	h.t_user_id = @ma AND
	date_erfassung  between @von AND @bis 
	/*group by h.t_adresse_id*/
END

if (@modus = 5) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_anrufstatistik h
	where 
	/*h.txt_titel LIKE '%Mutiert am%'   AND*/
	h.modus = 5 AND
	h.t_user_id = @ma AND
	date_erfassung  between @von AND @bis 
	/*group by h.t_adresse_id*/
END

if (@modus = 6) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_anrufstatistik h
	where 
	/*txt_titel LIKE '%Neue Adresse erfasst am%'  AND*/
	h.modus = 6 AND
	h.t_user_id = @ma AND
	date_erfassung  between @von AND @bis 
	/*group by h.t_adresse_id*/
END

if (@modus = 7) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_anrufstatistik h
	where 
	/*txt_titel = 'Adresse ungültig'  AND*/
	h.modus = 7 AND
	h.t_user_id = @ma AND
	date_erfassung  between @von AND @bis 
	/*group by h.t_adresse_id*/
END

if (@modus = 8) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_anrufstatistik h
	where 
	/*txt_history ='Grund : Nummer nicht mehr in Betrieb'  AND*/
	h.modus = 8 AND
	h.t_user_id = @ma AND
	date_erfassung  between @von AND @bis 
	/*group by h.t_adresse_id*/
END

if (@modus = 9) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_anrufstatistik h
	where 
	/* txt_history ='Grund : Privatnummer'  AND */
	h.modus = 9 AND
	h.t_user_id = @ma AND
	date_erfassung  between @von AND @bis 
	/*group by h.t_adresse_id*/
END

if (@modus = 10) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_anrufstatistik h
	where 
	/*txt_history ='Grund : Firma nicht mehr vorhanden'  AND*/
	h.modus = 10 AND
	h.t_user_id = @ma AND
	date_erfassung  between @von AND @bis 
	/*group by h.t_adresse_id*/
END

if (@modus = 11) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_anrufstatistik h
	where 
	/*txt_history ='Grund : Bereits Kunde' AND*/
	h.modus = 11 AND
	h.t_user_id = @ma AND
	date_erfassung  between @von AND @bis 
	/*group by h.t_adresse_id*/
END

if (@modus = 12) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_anrufstatistik h
	where 
	/* txt_history ='Grund : Doppelter Datensatz'  AND */ 
	h.modus = 10 AND 
	h.t_user_id = @ma AND
	date_erfassung  between @von AND @bis 
	/*group by h.t_adresse_id*/
END

if (@modus = 13) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_anrufstatistik h
	where 
	/* txt_history ='Grund : Schon optmiert'  AND */
	h.modus = 13 AND
	h.t_user_id = @ma AND
	date_erfassung  between @von AND @bis 
	/*group by h.t_adresse_id*/
END

if (@modus = 14) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_anrufstatistik h
	where 
	/* txt_history ='Grund : Sonstiges'  AND */
	h.modus = 14 AND
	h.t_user_id = @ma AND
	date_erfassung  between @von AND @bis 
	/*group by h.t_adresse_id*/
END


if (@modus = 15) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_pendenz p
	where 
	t_user_id_von = @ma AND
	erf_date  between @von AND @bis 
	/*group by h.t_adresse_id*/
END

if (@modus = 16) 
BEGIN
	SELECT @anzahl = COUNT(t_adresse_id) from t_newsletter l
	where 
	l.t_user_id = @ma AND
	l.date_erfassung  between @von AND @bis 
	/*group by l.t_adresse_id*/
END

if (@modus = 17)
BEGIN
(SELECT @anzahl =  COUNT(t_adresse_id) from t_termin
	where 
	verschoben <> 1		AND
	t_adresse_id <> 0 		AND
	CA_id = @ma 			AND
	datum between @von AND @bis  AND
	del = 0
	)
END


if (@modus = 18)
BEGIN
	(SELECT @anzahl =  COUNT(t_adresse_id) from t_termin
	where 
	verschoben <> 1		AND
	t_adresse_id <> 0 		AND
	CA_id = @ma 			AND
	von between @von AND @bis 	AND
	del = 0
	)

END

if (@modus = 19)
BEGIN
	(SELECT @anzahl =  COUNT(t_adresse_id) from t_qualAdresse
	where 
	t_user_id = @ma AND
	erfasst between @von AND @bis
	)

END

if (@modus = 20)
BEGIN
	(SELECT @anzahl =  COUNT(t_adresse_id) from t_pendenz
	where 
	t_pendenzart_id = 70 AND
	t_user_id = @ma 			AND
	erf_date between @von AND @bis 
	)

END


RETURN @anzahl
end


/*
anruf = 'Anruf nicht angenommen' 
entscheidungstraeger = 'Entscheidungsträger erreicht' 
entscheidungstraeger = 'Entscheidungsträger nicht erreicht' 
txt_titel LIKE '%Mutiert am%' 
txt_titel LIKE '%Neue Adresse erfasst am%' 


txt_titel = 'Adresse ungültig'
txt_history = ""
Gründe sind unter txt_history:
txt_history ='Grund : Nummer nicht mehr in Betrieb'
txt_history ='Grund : Privatnummer'
txt_history ='Grund : Firma nicht mehr vorhanden'
txt_history ='Grund : Bereits Kunde'
txt_history ='Grund : Doppelter Datensatz'
txt_history ='Grund : Schon optmiert'
txt_history ='Grund : Sonstiges'
*/














GO

