CREATE procedure [dbo].[dt_engine]
@myEngine varchar (50),
@coutryID int

AS
SET NOCOUNT ON
declare @temp_id int


	if exists (Select ID from t_engine where name = @myEngine)
		BEGIN
			Select ID from t_engine where name = @myEngine
		END
		
	else
		BEGIN 
			 Insert into t_engine (name,countryID) values ( @myEngine, @coutryID)
			SELECT @temp_id = Scope_Identity()
   			 SELECT temp_id = @temp_id

		END
GO

