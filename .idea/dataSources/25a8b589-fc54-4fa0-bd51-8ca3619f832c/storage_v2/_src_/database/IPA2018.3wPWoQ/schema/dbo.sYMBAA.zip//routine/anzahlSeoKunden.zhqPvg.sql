-- ======================================================
-- Author:		Gerd Thillmann
-- Create date: 19.08.2010
-- Description:	Gibt die Anzahl der Kundendomains 
--	bis zum übergebenen (nichtgekündigt) Zeitraum zurück. 
-- ======================================================
CREATE FUNCTION [dbo].[anzahlSeoKunden] (@gekuendigtbis datetime)
RETURNS int
AS
BEGIN
declare @t_url_id int
declare @txt_www NVARCHAR(100)
declare @vertragsende datetime
declare @gekuendigt datetime
declare @anzahl int
set @anzahl = 0

declare c_kw CURSOR FOR
select U.id, U.txt_www from t_url U inner join t_adresse A 
on U.t_adresse_id = A.id 
where A.adresse_ungueltig = 0 
open c_kw
FETCH NEXT FROM c_kw INTO @t_url_id, @txt_www
WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT TOP 1 @gekuendigt = gekuendigt from t_vertrag_typ V 
	where 
	V.t_url_id = @t_url_id 
	order by V.id desc
	
	IF (@gekuendigt >= @gekuendigtbis) OR (@gekuendigt IS NULL) 
	BEGIN
		set @anzahl = @anzahl + 1
	END

FETCH NEXT FROM c_kw INTO @t_url_id, @txt_www
END
close c_kw
DEALLOCATE c_kw
return @anzahl

END
GO

