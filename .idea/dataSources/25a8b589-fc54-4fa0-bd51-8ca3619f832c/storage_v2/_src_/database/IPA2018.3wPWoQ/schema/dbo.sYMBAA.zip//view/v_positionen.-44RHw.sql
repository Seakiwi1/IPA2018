CREATE VIEW dbo.v_positionen
AS
SELECT DISTINCT RS.keywordsID, RS.reportID, RS.engineID, R.page
FROM         dbo.t_report_spec AS RS INNER JOIN
                      dbo.t_ranking AS R ON RS.rankingID = R.ID
GROUP BY RS.keywordsID, RS.reportID, RS.engineID, R.page
GO

