
CREATE PROCEDURE [dbo].[dt_insert_auto_vertraege]
@datum_bis datetime
AS
SET NOCOUNT ON;
BEGIN


	declare @t_url_id int
	declare @txt_www nvarchar(50)
	declare @t_vertrag_typ_id int
	declare @vertragsende datetime
	declare @vertragsstart datetime
	declare @gekuendigt datetime
	declare @t_adresse_id int
	declare @vertragsdauer int
	declare @standardpreis money
	declare @spezialpreis money
	declare @anzahl_kw int

	declare c_kw CURSOR FOR
	SELECT U.id, U.txt_www
	from t_url U
	open c_kw
	FETCH NEXT FROM c_kw INTO @t_url_id, @txt_www
	WHILE @@FETCH_STATUS = 0
	BEGIN

		declare v_cr CURSOR FOR 
		SELECT top 1 gekuendigt ,vertragsdauer, vertragsstart, vertragsende, standardpreis, spezialpreis, anzahl_kw from t_vertrag_typ V 
		where t_url_id = @t_url_id order by vertragsstart desc
		open v_cr
		FETCH NEXT FROM v_cr INTO @gekuendigt, @vertragsdauer, @vertragsstart, @vertragsende, @standardpreis, @spezialpreis, @anzahl_kw 
		WHILE @@FETCH_STATUS = 0
		BEGIN
			

			if (@gekuendigt IS NULL AND @vertragsende < @datum_bis)
			BEGIN
				/*Print @txt_www
				print @vertragsdauer
				print @gekuendigt*/			

				insert into t_vertrag_typ(t_url_id, vertragsdauer, vertragsstart, vertragsende, standardpreis, spezialpreis, anzahl_kw, bearbeitet)
				VALUES(@t_url_id, 1, dateAdd(day,1,@vertragsende), dateAdd(year,1,@vertragsende), @standardpreis, @spezialpreis, @anzahl_kw, 3)
			
			END
			set @gekuendigt = NULL
			
		FETCH NEXT FROM v_cr INTO @gekuendigt, @vertragsdauer, @vertragsstart, @vertragsende, @standardpreis, @spezialpreis, @anzahl_kw
		END
		close v_cr
		DEALLOCATE v_cr
		
	FETCH NEXT FROM c_kw INTO @t_url_id, @txt_www
	END
	close c_kw
	DEALLOCATE c_kw

END
GO

