/*
Zeitraum :
1 - Termine die in dieser Zeit gesetzt wurden
2 - Termine die in dieser Zeit besucht / nicht besucht wurden

Modus : 
1 - alle CA 	und 		AG X
2 - 		CA Y 	und alle AG 
3 - alle CA 	und alle AG
4 - 		CA Y 	und 		AG X
*/

/*
Status : 
0 - Neu 
4 - wahrgenommen
7 - nicht wahrgenommen
9 - abgeschlossen
*/

/*
Verschoben :
0 - nein
1 - verschoben worden
*/

CREATE FUNCTION [dbo].[terminstatistik] (@von datetime,@bis datetime,@modus int,@ca int,@ag int, @zeitraum int,@status int,@verschoben int)  
RETURNS int  AS 
BEGIN 

DECLARE @anzahl int

set @anzahl = 0	
set @bis = dateadd(day, 1, @bis)
/* Termine die in dieser Zeit gesetzt wurden */
	IF (@zeitraum = 1) 	
		BEGIN
		IF (@modus = 1) 
			BEGIN
				(SELECT @anzahl =  COUNT(t_adresse_id) from t_termin
				where 
				verschoben = @verschoben 	AND
				t_adresse_id <> 0 		AND
				AG_id = @ag 			AND
				datum between @von AND @bis 
				)
			END
		IF (@modus = 2)
			BEGIN 
				 (SELECT @anzahl =  COUNT(t_adresse_id) from t_termin
				where 
				status = @status 		AND 
				verschoben = @verschoben 	AND
				t_adresse_id <> 0 		AND
				CA_id = @ca 			AND
				datum between @von AND @bis
				)
			END
		IF (@modus = 3) 
			BEGIN
				 (SELECT @anzahl =  COUNT(t_adresse_id) from t_termin 
				where 
				status = @status 		AND 
				verschoben = @verschoben 	AND
				t_adresse_id <> 0 		AND
				datum between @von AND @bis
				)
			END
		IF (@modus = 4) 
			BEGIN
				 (SELECT @anzahl = COUNT(t_adresse_id) from t_termin 
				where 
				status = @status 		AND 
				verschoben = @verschoben 	AND
				t_adresse_id <> 0 		AND
				CA_id = @ca 			AND
				AG_id = @ag 			AND
				datum between @von AND @bis
				)

			END

		END
/* Termine die in dieser Zeit besucht / nicht besucht wurden */	
	IF (@zeitraum = 2) 	
		BEGIN
		IF (@modus = 1) 
			BEGIN
				(SELECT @anzahl =  COUNT(t_adresse_id) from t_termin
				where 
				status = @status 		AND 
				verschoben = @verschoben 	AND
				t_adresse_id <> 0 		AND
				AG_id = @ag 			AND
				bis between @von 	AND @bis 
				)
			END		
		IF (@modus = 2) 
			BEGIN
				(SELECT @anzahl =  COUNT(t_adresse_id) from t_termin
				where 
				status = @status 		AND 
				verschoben = @verschoben 	AND
				t_adresse_id <> 0 		AND
				CA_id = @ca 			AND
				bis between @von AND @bis
				)
			END
		IF (@modus = 3) 
			BEGIN
				(SELECT @anzahl =  COUNT(t_adresse_id) from t_termin
				where 
				status = @status			 AND 
				verschoben = @verschoben	 AND
				t_adresse_id <> 0 		 AND
				bis between @von AND @bis
				)
			END
		IF (@modus = 4) 
			BEGIN
				(SELECT @anzahl =  COUNT(t_adresse_id) from t_termin 
				where 
				status = @status 		AND 
				verschoben = @verschoben 	AND
				t_adresse_id <> 0 		AND
				CA_id = @ca 			AND
				AG_id = @ag 			AND
				bis between @von AND @bis
				)
			END
		END

RETURN @anzahl

END


GO

