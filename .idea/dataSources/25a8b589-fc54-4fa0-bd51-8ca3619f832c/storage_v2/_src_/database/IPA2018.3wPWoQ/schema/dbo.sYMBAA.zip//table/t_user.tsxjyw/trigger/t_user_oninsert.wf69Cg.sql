
CREATE TRIGGER t_user_oninsert
   ON  t_user
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	declare @notExistingEmails table (email nvarchar(50))

	insert into @notExistingEmails(email) 
	select i.email 
	from inserted i 
	where email is not null and email <> '' and not exists(select 1 from t_newsletter_email e where e.email = i.email)

    -- Insert statements for trigger here
	insert into t_newsletter_email(vorname, nachname, anrede, email, angemeldet)
	select i.vorname, i.name, i.t_anrede_id, i.email, getdate()
	from inserted i join @notExistingEmails ne on i.email = ne.email

	-- 1003 - Mitarbeiter
	insert into gn_customcategoryrecipients(category_id, recipient_id)
	select 1003, r.id 
	from 
		t_newsletter_email r 
		join inserted i on r.email = i.email 
		join @notExistingEmails ne on i.email = ne.email
END
GO

