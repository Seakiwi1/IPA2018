CREATE VIEW dbo.v_kw_def
AS
SELECT     A.int_adress_status_ID, A.txt_firma AS firma, U.txt_www AS www, A.ID AS Aid, U.ID AS uID, S.t_user_id AS uUSID, 
                      S.begin_optimierung AS t_seo_begin_optimierung, S.ID
FROM         dbo.t_adresse AS A INNER JOIN
                      dbo.t_url AS U ON A.ID = U.t_adresse_id INNER JOIN
                      dbo.t_seo AS S ON U.ID = S.t_url_id LEFT OUTER JOIN
                      dbo.t_kw_vorschlag_spec AS VS ON S.t_kw_vorschlag_id = VS.t_kw_vorschlag_id LEFT OUTER JOIN
                      dbo.t_keywords_set AS V ON VS.t_keywords_set_id = V.ID LEFT OUTER JOIN
                      dbo.t_vertrag_typ AS VT ON U.ID = VT.t_url_id
WHERE     (V.ID IS NULL) AND (A.int_adress_status_ID BETWEEN 8 AND 10 OR
                      A.int_adress_status_ID = 13) AND (VT.gekuendigt IS NULL) OR
                      (V.ID IS NULL) AND (A.int_adress_status_ID BETWEEN 8 AND 10 OR
                      A.int_adress_status_ID = 13) AND (VT.gekuendigt >= DATEADD(month, 1, GETDATE()))
GO

