create procedure gn_BlackListRecipient
(
	@id int
)
as

update t_newsletter_email set abgemeldet = getdate() where id = @id;
GO

