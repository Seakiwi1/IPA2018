
	create view [dbo].[gn_RecipientsWithTPData]
	with schemabinding
	as
		select n.id recipient_id, a.id as address_id
		from dbo.t_newsletter_email n
			join dbo.t_adresse a on n.email = a.txt_tp_email
		where ((a.txt_tp_name is not null and a.txt_tp_name <> '')
				or (a.txt_tp_vorname is not null and a.txt_tp_vorname <> ''))
                and (adresse_ungueltig is null or adresse_ungueltig = 0)
  GO

