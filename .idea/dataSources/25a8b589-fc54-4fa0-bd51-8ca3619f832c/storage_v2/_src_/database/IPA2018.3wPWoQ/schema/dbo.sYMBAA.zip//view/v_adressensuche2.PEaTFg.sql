CREATE VIEW dbo.v_adressensuche2
AS
SELECT     A.ID AS aID, U.ID AS t_url_id, RTRIM(LTRIM(A.txt_www)) AS Url1, RTRIM(LTRIM(U.txt_www)) AS Url2, A.int_adress_status_ID AS astatus, 
                      RTRIM(LTRIM(A.txt_firma)) AS Firma, P.plz AS PLZ, A.adresse_ungueltig, RTRIM(LTRIM(P.ort_27)) AS Ort, K.txt_kuerzel_de AS Kanton, 
                      A.int_land_ID AS int_land_id, P.t_kanton_ID
FROM         dbo.t_adresse AS A INNER JOIN
                      dbo.t_plz AS P ON A.int_plz_ID = P.ID INNER JOIN
                      dbo.t_kanton AS K ON A.int_kanton_ID = K.ID LEFT OUTER JOIN
                      dbo.t_url AS U ON A.ID = U.t_adresse_id LEFT OUTER JOIN
                      dbo.t_domainalias AS DA ON U.ID = DA.t_url_id
GO

