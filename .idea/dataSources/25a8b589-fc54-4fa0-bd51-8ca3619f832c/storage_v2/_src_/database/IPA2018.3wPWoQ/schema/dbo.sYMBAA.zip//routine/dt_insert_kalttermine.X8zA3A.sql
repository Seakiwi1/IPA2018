CREATE procedure [dbo].[dt_insert_kalttermine]

@von		int,
@datum	datetime,
@int_getan		int,
@txt_div		varchar (100),
@int_anzahl	int

AS
SET NOCOUNT ON

declare @temp_id int


BEGIN
	Insert into t_kalttermine (von , datum , int_getan, txt_div, int_anzahl) values (@von,@datum,@int_getan,@txt_div,@int_anzahl)

SELECT @temp_id = Scope_Identity()
SELECT temp_id = @temp_id

END
GO

