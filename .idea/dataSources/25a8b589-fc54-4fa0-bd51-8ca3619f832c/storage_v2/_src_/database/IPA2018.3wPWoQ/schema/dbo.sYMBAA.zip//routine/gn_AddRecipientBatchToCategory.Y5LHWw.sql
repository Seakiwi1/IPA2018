create procedure gn_AddRecipientBatchToCategory
(
	@categoryid int,
	@batchID uniqueidentifier
)
as

exec gn_ClearCustomCategory @categoryid;
declare @now datetime 
set @now = getdate();


insert into t_newsletter_email(vorname, nachname, anrede, email, angemeldet) 
select vorname, nachname, anrede, email, @now
from gn_RecipientBatches b
where b.batchid = @batchid
	and not exists(select 1 from t_newsletter_email e where e.email = b.email)

insert into gn_CustomCategoryRecipients(category_id, recipient_id)
select @categoryid, e.ID
from t_newsletter_email e join gn_RecipientBatches b on e.email = b.email
where b.batchid = @batchid

GO

