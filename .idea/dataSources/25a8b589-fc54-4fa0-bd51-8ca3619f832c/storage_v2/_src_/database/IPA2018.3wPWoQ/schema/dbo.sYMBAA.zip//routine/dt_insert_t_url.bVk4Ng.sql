

CREATE procedure [dbo].[dt_insert_t_url]

@txt_www			nvarchar(50),
@t_adresse_id		int,
@vertragsstart		datetime,
@vertragsende		datetime,
@vertragsdauer		int,
@kundenblatversand	datetime,
@gratis_monate		int,
@backlink		int,
@gekuendigt			datetime,
@eingeschrieben		datetime,
@auftragsnummer		nvarchar(50),
@vertrag_bemerkung	nvarchar(2000),
@anzahl_kw			int,
@standardpreis		money,
@spezialpreis		money,
@typeID				int,
@hosting_Vertragstart	datetime,
@hosting_Vertragsende	datetime,
@ftp_user			nvarchar(100),
@ftp_passwort		nvarchar(100),
@frontpageerweiterung		int	,
@anbieter			nvarchar(100),
@anbieter_nr		nvarchar(100),
@anbieter_passwort	nvarchar(100),
@Admin_Email_konto	nvarchar(100),
@Admin_Email_passwort	nvarchar(100),
@SQL_user			nvarchar(100),
@SQL_passwort		nvarchar(100),
@web_stats_login	nvarchar(100),
@web_stats_passwort		nvarchar(100),
@hosting_spec_bemerkung	nvarchar(2000),
@hosting_verantwortlich 		int,
@ist_php				 int,
@ist_asp			 int,
@ist_perl			 int,
@ist_cgi			 int,
@ist_cfml			 int,
@ist_access			 int,
@ist_ms_sql			 int,
@ist_mysql			 int,
@webdesign_verantwortlich	 int,
@webdesign_bemerkung nvarchar(2000)

AS

SET NOCOUNT ON

declare @temp_hosting_id int

declare @temp_email_id int
declare @temp_url_id int


BEGIN
	Insert into t_hosting (beiUns) values (0)

	 set @temp_hosting_id = Scope_Identity()

	Insert into t_email (bemerkung) values (NULL)

	 set @temp_email_id = Scope_Identity()

	Insert into t_url (t_hosting_id,t_email_id,t_adresse_id,txt_www,backlink) values (@temp_hosting_id,@temp_email_id,@t_adresse_id,LTRIM(RTRIM(@txt_www)),@backlink)

	 set @temp_url_id = Scope_Identity()

if @typeID = 1

BEGIN
	Insert into t_vertrag_typ (vertragsdauer,vertragsstart,vertragsende,gekuendigt,eingeschrieben,kundenblatversand,bemerkung,gratis_monate,auftragsnummer,t_url_id,anzahl_kw,standardpreis,spezialpreis,backlink) values (@vertragsdauer,@vertragsstart,@vertragsende,@gekuendigt,@eingeschrieben,@kundenblatversand,@vertrag_bemerkung,@gratis_monate,@auftragsnummer,@temp_url_id,@anzahl_kw,@standardpreis,@spezialpreis, CONVERT(BIT,@backlink))
END

if @typeID = 6
BEGIN
	Insert into t_hosting_spec (Vertragstart,Vertragsende,ftp_user,ftp_passwort,frontpageerweiterung,anbieter,anbieter_nr,anbieter_passwort,Admin_Email_konto,Admin_Email_passwort,SQL_user,SQL_passwort,web_stats_login,web_stats_passwort,bemerkungen,t_user_id,ist_php,ist_asp,ist_perl,ist_cgi,ist_cfml,ist_access,ist_ms_sql,ist_mysql,t_url_id) values (@hosting_Vertragstart,@hosting_Vertragsende,@ftp_user,@ftp_passwort,@frontpageerweiterung,@anbieter,@anbieter_nr,@anbieter_passwort,@Admin_Email_konto,@Admin_Email_passwort,@SQL_user,@SQL_passwort,@web_stats_login,@web_stats_passwort,@hosting_spec_bemerkung,@hosting_verantwortlich,@ist_php,@ist_asp,@ist_perl,@ist_cgi,@ist_cfml,@ist_access,@ist_ms_sql,@ist_mysql,@temp_url_id)
END

if @typeID = 7
BEGIN

	Insert into t_webdesign (verantwortlich,bemerkungen,t_url_id) values (@webdesign_verantwortlich,@webdesign_bemerkung,@temp_url_id)
	
END



END

GO

