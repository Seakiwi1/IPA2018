CREATE procedure [dbo].[dt_insert_korrespondenz_history]

@t_adresse_id		 int,
@vorname		nvarchar(30),
@name		nvarchar(30),
@txt_titel	nvarchar(60),
@txt_history	nvarchar(500),
@date_erfassung		datetime,
@von			int,
@an			int,
@prioritaet		int,
@erledigt		bit,
@update_insert	int,
@datumerledigt		datetime,
@korrID		int

AS
SET NOCOUNT ON

declare @temp_id int
declare @update_or_insert int	

set @update_or_insert = @update_insert

if ( @update_or_insert = 0)
BEGIN
	Insert into t_history (t_adresse_id,vorname,name,anzeige_status,txt_titel,txt_history,date_erfassung) values (@t_adresse_id,@vorname,@name,2,@txt_titel,@txt_history,@date_erfassung)

	 set @temp_id = Scope_Identity()

	Insert into t_korrespondenz (von,an,prioritaet,erledigt,t_history_id_n) values (@von,@an,@prioritaet,@erledigt,@temp_id)

END

if ( @update_or_insert = 1)
BEGIN
	Insert into t_history (t_adresse_id,vorname,name,anzeige_status,txt_titel,txt_history,date_erfassung) values (@t_adresse_id,@vorname,@name,2,@txt_titel,@txt_history,@date_erfassung)

	 set @temp_id = Scope_Identity()

	Update t_korrespondenz set erledigt = @erledigt , datumerledigt = @datumerledigt , t_history_id_a = @temp_id where id = @korrID
END
GO

